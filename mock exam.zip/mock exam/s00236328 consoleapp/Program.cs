﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using S00236328_classlibrary;
namespace s00236328_consoleapp
{
    public class Program
    {
        static void Main(string[] args)
        {
            using (var context = new FlightContext())
            {
                var passengerBookings = context.Flights
                                               //.Include(pb => pb.Flight)
                                               //.Include(pb => pb.Passenger)
                                               .ToList();

                foreach (var booking in passengerBookings)
                {
                    //Console.WriteLine($"Booking ID: {booking.Id}, Flight: {booking.Flight.FlightNo}, Passenger: {booking.Passenger.PassengerName}, Ticket Type: {booking.TicketType}, Ticket Cost: {booking.TicketCost}, Baggage Charge: {booking.BaggageCharge}");
                }
            }

           // list_passengers(1);
        }
        static void list_passengers(int FlightID)
        {
            using (var context = new FlightContext())
            {
                var passengers = context.PassengerBookings
      .Include(pb => pb.Flight)
      .Include(pb => pb.Passenger)
      .Where(pb => pb.FlightId == FlightID)
      .Select(pb => new
      {
          PassengerName = pb.Passenger.PassengerName,
          TicketType = pb.TicketType.ToString(),
          Destination = pb.Flight.Destination
      })
      .ToList();


                if (passengers.Any())
                {
                    Console.WriteLine($"Passengers for Flight ID {FlightID}:");
                    foreach (var passenger in passengers)
                    {
                        Console.WriteLine($"Name: {passenger.PassengerName}, Ticket Type: {passenger.TicketType}, Destination: {passenger.Destination}");
                    }
                }
                else
                {
                    Console.WriteLine($"No passengers found for Flight ID {FlightID}.");
                }
            }
        }
    }
}
